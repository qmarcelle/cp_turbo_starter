// @src/utils/logging/server-logger.ts
import winston from 'winston';

export const createServerLogger = (service: string) => {
  return winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.errors({ stack: true }),
      // Use Winston's built-in masking
      winston.format((info) => {
        if (info.username) {
          info.username = info.username.replace(/./g, '*');
        }
        if (info.sessionId) {
          info.sessionId = '****';
        }
        if (info.token) {
          info.token = '****';
        }
        return info;
      })(),
      winston.format.json()
    ),
    defaultMeta: {
      service,
      environment: process.env.NODE_ENV
    },
    transports: [
      new winston.transports.Console({
        format: process.env.NODE_ENV === 'development' 
          ? winston.format.prettyPrint() 
          : winston.format.json()
      })
    ]
  });
};