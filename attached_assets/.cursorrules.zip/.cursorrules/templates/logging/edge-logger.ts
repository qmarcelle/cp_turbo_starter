// @src/utils/logging/edge-logger.ts
import pino from 'pino';
import { headers } from 'next/headers';

export const createEdgeLogger = (component: string) => {
  return pino({
    level: process.env.LOG_LEVEL || 'info',
    redact: {
      paths: ['username', 'sessionId', 'token', 'mfaCode'],
      censor: '****'
    },
    formatters: {
      level: (label) => ({ level: label }),
      bindings: () => ({
        pid: process.pid,
        component
      })
    },
    mixin() {
      const headersList = headers();
      return {
        correlationId: headersList.get('x-correlation-id'),
        requestId: headersList.get('x-request-id')
      };
    }
  });
};