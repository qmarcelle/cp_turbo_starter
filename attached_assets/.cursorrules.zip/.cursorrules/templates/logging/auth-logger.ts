// @src/utils/logging/auth-logger.ts
import { createServerLogger } from './server-logger';
import { createEdgeLogger } from './edge-logger';

export class AuthLogger {
  private logger;

  constructor(isEdge: boolean = false) {
    this.logger = isEdge 
      ? createEdgeLogger('auth')
      : createServerLogger('auth');
  }

  logLoginAttempt(username: string, correlationId: string) {
    // Data will be automatically masked by logger configuration
    this.logger.info('Login attempt', {
      correlationId,
      username,
      timestamp: new Date().toISOString()
    });
  }

  logMFAAttempt(username: string, deviceType: string, correlationId: string) {
    this.logger.info('MFA verification attempt', {
      correlationId,
      username,
      deviceType,
      timestamp: new Date().toISOString()
    });
  }

  logError(error: Error, correlationId: string) {
    this.logger.error('Error occurred', {
      correlationId,
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
  }
}