import { Redis } from '@upstash/redis';
import { encrypt, decrypt } from '@/utils/encryption';

const redis = new Redis({
  url: process.env.REDIS_URL!,
  token: process.env.REDIS_TOKEN!
});

export const sessionStore = {
  async get(sessionId: string): Promise<SessionData | null> {
    const data = await redis.get();
    if (!data) return null;
    return {
      ...data,
      esToken: decrypt(data.esToken),
      pingOneToken: decrypt(data.pingOneToken)
    };
  },

  async set(sessionId: string, data: SessionData): Promise<void> {
    await redis.set(
      ,
      {
        ...data,
        esToken: encrypt(data.esToken),
        pingOneToken: encrypt(data.pingOneToken)
      },
      {
        ex: 3600 // 1 hour expiry
      }
    );
  },

  async destroy(sessionId: string): Promise<void> {
    await redis.del();
  }
};

export const rateLimiter = {
  async checkLoginAttempts(ip: string): Promise<boolean> {
    const attempts = await redis.incr();
    if (attempts === 1) {
      await redis.expire(, 900); // 15 minutes
    }
    return attempts <= 5;
  },

  async checkMFAAttempts(userId: string): Promise<boolean> {
    const attempts = await redis.incr();
    if (attempts === 1) {
      await redis.expire(, 600); // 10 minutes
    }
    return attempts <= 3;
  }
};
