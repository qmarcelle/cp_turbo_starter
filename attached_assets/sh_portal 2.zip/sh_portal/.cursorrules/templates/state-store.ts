import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { encrypt, decrypt } from '@/utils/encryption';

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  mfaStatus: MFAStatus;
  mfaDevices: MFADevice[];
  interactionId?: string;
  interactionToken?: string;
  error: string | null;
}

interface AuthActions {
  setUser: (user: User | null) => void;
  setMFAStatus: (status: MFAStatus) => void;
  setMFADevices: (devices: MFADevice[]) => void;
  setInteractionTokens: (tokens: { interactionId: string; interactionToken: string }) => void;
  clearSession: () => void;
  setError: (error: string | null) => void;
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  mfaStatus: 'idle',
  mfaDevices: [],
  error: null
};

export const useAuthStore = create<AuthState & AuthActions>()(
  persist(
    (set) => ({
      ...initialState,

      setUser: (user) => set({ user, isAuthenticated: !!user }),
      
      setMFAStatus: (mfaStatus) => set({ mfaStatus }),
      
      setMFADevices: (mfaDevices) => set({ mfaDevices }),
      
      setInteractionTokens: (tokens) => set({ 
        interactionId: tokens.interactionId,
        interactionToken: encrypt(tokens.interactionToken)
      }),
      
      clearSession: () => set(initialState),
      
      setError: (error) => set({ error })
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);
