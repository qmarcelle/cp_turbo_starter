# #!/bin/bash

# # Root directory setup
# mkdir -p src/{app,components,utils,lib,tests}

# # Authentication related directories
# mkdir -p src/app/\(auth\)/login
# mkdir -p src/components/auth/MFAFlow
# mkdir -p src/utils/{api,logging}
# mkdir -p src/lib/auth
# mkdir -p src/tests/{auth,api,integration,components,e2e}

# # Create base configuration files
# cat > next.config.js << EOL
# /** @type {import('next').NextConfig} */
# const nextConfig = {
#   experimental: {
#     serverActions: true,
#   },
# }

# module.exports = nextConfig
# EOL

# # Create environment file
# cat > .env.local << EOL
# # ES API Configuration
# ES_API_BASE_URL=
# ES_API_POLICY_ID=
# ES_API_APP_ID=

# # PingOne Configuration
# PING_ONE_TOKEN_URL=

# # Redis Configuration
# REDIS_URL=
# REDIS_TOKEN=

# # Logging Configuration
# SPLUNK_TOKEN=
# SPLUNK_URL=

# # Auth Configuration
# NEXTAUTH_SECRET=
# NEXTAUTH_URL=http://localhost:3000
# EOL

# # Create base TypeScript configuration
# cat > tsconfig.json << EOL
# {
#   "compilerOptions": {
#     "target": "es5",
#     "lib": ["dom", "dom.iterable", "esnext"],
#     "allowJs": true,
#     "skipLibCheck": true,
#     "strict": true,
#     "forceConsistentCasingInFileNames": true,
#     "noEmit": true,
#     "esModuleInterop": true,
#     "module": "esnext",
#     "moduleResolution": "node",
#     "resolveJsonModule": true,
#     "isolatedModules": true,
#     "jsx": "preserve",
#     "incremental": true,
#     "plugins": [
#       {
#         "name": "next"
#       }
#     ],
#     "paths": {
#       "@/*": ["./src/*"]
#     }
#   },
#   "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
#   "exclude": ["node_modules"]
# }
# EOL

# # Create package.json with required dependencies
# cat > package.json << EOL
# {
#   "name": "shared-health-portal",
#   "version": "0.1.0",
#   "private": true,
#   "scripts": {
#     "dev": "next dev",
#     "build": "next build",
#     "start": "next start",
#     "lint": "next lint",
#     "test": "jest",
#     "test:e2e": "cypress run",
#     "cypress:open": "cypress open"
#   },
#   "dependencies": {
#     "@upstash/redis": "^1.28.0",
#     "axios": "^1.6.2",
#     "next": "14.0.3",
#     "next-auth": "^5.0.0-beta.3",
#     "react": "^18",
#     "react-dom": "^18",
#     "zustand": "^4.4.6"
#   },
#   "devDependencies": {
#     "@types/jest": "^29.5.10",
#     "@types/node": "^20",
#     "@types/react": "^18",
#     "@types/react-dom": "^18",
#     "autoprefixer": "^10.0.1",
#     "cypress": "^13.6.0",
#     "eslint": "^8",
#     "eslint-config-next": "14.0.3",
#     "jest": "^29.7.0",
#     "postcss": "^8",
#     "tailwindcss": "^3.3.0",
#     "typescript": "^5"
#   }
# }
# EOL

# # Create Jest configuration
# cat > jest.config.js << EOL
# const nextJest = require('next/jest')

# const createJestConfig = nextJest({
#   dir: './',
# })

# const customJestConfig = {
#   setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
#   moduleDirectories: ['node_modules', '<rootDir>/'],
#   moduleNameMapper: {
#     '^@/(.*)$': '<rootDir>/src/$1',
#   },
#   testEnvironment: 'jest-environment-jsdom',
# }

# module.exports = createJestConfig(customJestConfig)
# EOL

# # Create Jest setup file
# cat > jest.setup.js << EOL
# import '@testing-library/jest-dom'
# EOL

# # Create Cypress configuration
# cat > cypress.config.ts << EOL
# import { defineConfig } from 'cypress'

# export default defineConfig({
#   e2e: {
#     baseUrl: 'http://localhost:3000',
#     supportFile: 'cypress/support/e2e.ts',
#   },
# })
# EOL

# # Create basic auth files
# cat > src/app/\(auth\)/login/page.tsx << EOL
# export default function LoginPage() {
#   return (
#     <div>
#       <h1>Login</h1>
#       {/* Login form will be added here */}
#     </div>
#   )
# }
# EOL

# # Install dependencies
# echo "Installing dependencies..."
# npm install

# # Create directories for Cypress
# mkdir -p cypress/{e2e,support,fixtures}

# # Initialize Git repository
# git init
# cat > .gitignore << EOL
# # dependencies
# /node_modules
# /.pnp
# .pnp.js

# # testing
# /coverage
# /cypress/videos
# /cypress/screenshots

# # next.js
# /.next/
# /out/

# # production
# /build

# # misc
# .DS_Store
# *.pem

# # debug
# npm-debug.log*
# yarn-debug.log*
# yarn-error.log*

# # local env files
# .env*.local

# # typescript
# *.tsbuildinfo
# next-env.d.ts
# EOL

# echo "Project structure created successfully!"


#!/bin/bash

# Create base directories
# mkdir -p src/{app,components,utils,lib,tests}
# mkdir -p .cursorrules/{context,snippets,templates}
# mkdir -p .vscode
# mkdir -p docs/cursor
# mkdir -p cypress/{e2e,support,fixtures}

# # Create main cursor configuration
# cat > .cursorrules/config.json << EOL
# {
#   "version": "1.0",
#   "project": "shared-health-portal",
#   "rules": {
#     "auth": {
#       "patterns": [
#         "src/app/(auth)/**/*",
#         "src/components/auth/**/*",
#         "src/lib/auth/**/*"
#       ],
#       "dependencies": [
#         "next-auth",
#         "@upstash/redis"
#       ]
#     },
#     "api": {
#       "patterns": [
#         "src/utils/api/**/*"
#       ]
#     },
#     "components": {
#       "patterns": [
#         "src/components/**/*"
#       ]
#     }
#   }
# }
# EOL

# # Create VSCode workspace settings
# cat > .vscode/settings.json << EOL
# {
#   "cursor.engineSettings": {
#     "experimentalInlineCompletion": true,
#     "experimentalTypeScript": true,
#     "experimentalNextjs": true
#   },
#   "cursor.features": {
#     "copilot": true,
#     "parameterHints": true,
#     "testing": true
#   },
#   "cursor.path": {
#     "@/*": ["./src/*"]
#   }
# }
# EOL

# # Create comprehensive type definitions
# cat > .cursorrules/types.d.ts << EOL
# declare namespace SharedHealth {
#   interface LoginRequest {
#     username: string;
#     password: string;
#     policyId?: string;
#     appId?: string;
#   }

#   interface LoginResponse {
#     message: string;
#     accessToken?: string;
#     mfaDeviceList?: MFADevice[];
#     interactionId?: string;
#     interactionToken?: string;
#   }

#   interface MFADevice {
#     deviceId: string;
#     deviceType: string;
#     value: string;
#   }

#   type LoginStatus =
#     | 'LOGIN_OK'
#     | 'MFA_REQUIRED_ONE_DEVICE'
#     | 'MFA_REQUIRED_MULTIPLE_DEVICES'
#     | 'VERIFY_EMAIL'
#     | 'ERROR';

#   interface ActionResponse<S, T> {
#     status: S;
#     data?: T;
#     error?: {
#       errorCode: string;
#       message: string;
#     };
#   }
# }
# EOL

# # Create enhanced auth context
# cat > .cursorrules/context/auth.md << EOL
# # Authentication Implementation Context

# ## Core Files
# - @src/app/(auth)/login/actions.ts: Main login actions
# - @src/app/(auth)/login/mfa.ts: MFA handling
# - @src/utils/api/esApi.ts: ES API integration

# ## Flow
# 1. User submits credentials
# 2. ES API validates through PingOne
# 3. MFA verification if required
# 4. Session establishment

# ## Implementation Details
# \`\`\`typescript
# // Login Action Structure
# export async function callLogin(
#   request: LoginRequest
# ): Promise<ActionResponse<LoginStatus, PortalLoginResponse>> {
#   const correlationId = \`\${request.username}_\${Date.now()}\`;
#   try {
#     // Implementation
#   } catch (error) {
#     // Error handling
#   }
# }

# // MFA Implementation
# export async function callSubmitMfaOtp(
#   params: SubmitMfaOtpArgs
# ): Promise<ActionResponse<SubmitMFAStatus, LoginResponse>> {
#   // Implementation
# }
# \`\`\`
# EOL

# # Create comprehensive snippets
# cat > .cursorrules/snippets/auth.json << EOL
# {
#   "loginAction": {
#     "prefix": "sh-login-action",
#     "body": [
#       "export async function callLogin(",
#       "  request: LoginRequest",
#       "): Promise<ActionResponse<LoginStatus, PortalLoginResponse>> {",
#       "  const correlationId = \`\${request.username}_\${Date.now()}\`;",
#       "  ",
#       "  try {",
#       "    authLogger.logLoginAttempt(request.username, correlationId);",
#       "    ",
#       "    const resp = await esApi.post<ESResponse<LoginResponse>>(",
#       "      '/mfAuthentication/loginAuthentication',",
#       "      {",
#       "        ...request,",
#       "        policyId: process.env.ES_API_POLICY_ID,",
#       "        appId: process.env.ES_API_APP_ID",
#       "      }",
#       "    );",
#       "    ",
#       "    const status = determineLoginStatus(resp.data.data?.message);",
#       "    ",
#       "    return {",
#       "      status,",
#       "      data: resp.data.data",
#       "    };",
#       "  } catch (error) {",
#       "    return handleLoginError(error, correlationId);",
#       "  }",
#       "}"
#     ],
#     "description": "Login action template"
#   }
# }
# EOL

# # Create test templates with complete patterns
# cat > .cursorrules/templates/test.ts << EOL
# import { describe, test, expect, jest } from '@jest/globals';
# import { callLogin, callSubmitMfaOtp } from '@/app/(auth)/login/actions';
# import { esApi } from '@/utils/api/esApi';

# jest.mock('@/utils/api/esApi');

# describe('{{name}}', () => {
#   beforeEach(() => {
#     jest.clearAllMocks();
#   });

#   test('should handle successful case', async () => {
#     // Arrange
#     const mockResponse = {
#       data: {
#         data: {
#           message: 'COMPLETED',
#           accessToken: 'test-token'
#         }
#       }
#     };
#     (esApi.post as jest.Mock).mockResolvedValue(mockResponse);

#     // Act
#     const result = await callLogin({
#       username: 'testUser',
#       password: 'testPass'
#     });

#     // Assert
#     expect(result.status).toBe('LOGIN_OK');
#   });

#   test('should handle error case', async () => {
#     // Arrange
#     const mockError = {
#       response: {
#         data: {
#           data: {
#             errorCode: 'UI-401'
#           }
#         }
#       }
#     };
#     (esApi.post as jest.Mock).mockRejectedValue(mockError);

#     // Act & Assert
#     const result = await callLogin({
#       username: 'testUser',
#       password: 'wrongPass'
#     });
#     expect(result.status).toBe('INVALID_CREDENTIALS');
#   });
# });
# EOL

# # Create enhanced patterns file
# cat > .cursorrules/patterns.json << EOL
# {
#   "auth": {
#     "loginAction": "export async function callLogin\\(",
#     "mfaAction": "export async function callSubmitMfaOtp\\(",
#     "errorHandler": "export function handleLoginError\\(",
#     "tokenManagement": "export async function refreshToken\\("
#   },
#   "components": {
#     "loginForm": "export function LoginForm\\(",
#     "mfaFlow": "export function MFAFlow\\(",
#     "emailVerification": "export function EmailVerification\\("
#   },
#   "api": {
#     "esApi": "export const esApi",
#     "errorMapping": "export const errorCodeMap"
#   }
# }
# EOL

# # Make files executable
# chmod -R +x .cursorrules

# echo "Enhanced Cursor configuration files created successfully!"


# cat > .cursorrules/implementation-patterns.json << EOL
# {
#   "auth": {
#     "loginFlow": {
#       "requiredSteps": [
#         "logAttempt",
#         "validateInput",
#         "callESApi",
#         "handleResponse",
#         "setSession",
#         "handleErrors"
#       ],
#       "requiredImports": [
#         "@/utils/api/esApi",
#         "@/utils/logging/auth-logger",
#         "@/utils/encryption"
#       ],
#       "errorHandling": {
#         "required": true,
#         "patterns": [
#           "correlationId tracking",
#           "error code mapping",
#           "user feedback"
#         ]
#       }
#     },
#     "mfaFlow": {
#       "requiredSteps": [
#         "deviceSelection",
#         "otpGeneration",
#         "otpValidation",
#         "sessionUpdate"
#       ]
#     }
#   }
# }
# EOL
# cat > .cursorrules/type-constraints.json << EOL
# {
#   "auth": {
#     "LoginRequest": {
#       "required": ["username", "password"],
#       "optional": ["policyId", "appId"],
#       "validation": {
#         "username": "string && minLength(3)",
#         "password": "string && minLength(8)"
#       }
#     },
#     "LoginResponse": {
#       "required": ["message"],
#       "conditional": {
#         "mfaDeviceList": "message === 'OTP_REQUIRED'",
#         "accessToken": "message === 'COMPLETED'"
#       }
#     }
#   }
# }
# EOL
# cat > .cursorrules/function-templates.json << EOL
# {
#   "loginAction": {
#     "structure": {
#       "pre": [
#         "const correlationId = generateCorrelationId(request.username);",
#         "authLogger.logLoginAttempt(request.username, correlationId);"
#       ],
#       "validation": [
#         "if (!request.username || !request.password) {",
#         "  return { status: LoginStatus.VALIDATION_FAILURE };"
#         "}"
#       ],
#       "apiCall": [
#         "const resp = await esApi.post<ESResponse<LoginResponse>>(",
#         "  '/mfAuthentication/loginAuthentication',",
#         "  buildRequestPayload(request)",
#         ");"
#       ],
#       "responseHandling": [
#         "const status = determineLoginStatus(resp.data.data?.message);",
#         "if (status === LoginStatus.LOGIN_OK) {",
#         "  await setWebsphereRedirectCookie(resp.data.data);",
#         "}"
#       ],
#       "errorHandling": [
#         "} catch (error) {",
#         "  return handleLoginError(error, correlationId);",
#         "}"
#       ]
#     }
#   }
# }
# EOL
# cat > .cursorrules/response-mapping.json << EOL
# {
#   "loginStatuses": {
#     "COMPLETED": "LOGIN_OK",
#     "OTP_REQUIRED": "MFA_REQUIRED_ONE_DEVICE",
#     "DEVICE_SELECTION_REQUIRED": "MFA_REQUIRED_MULTIPLE_DEVICES",
#     "EMAIL_VERIFICATION_REQUIRED": "VERIFY_EMAIL"
#   },
#   "errorCodes": {
#     "UI-401": {
#       "status": "INVALID_CREDENTIALS",
#       "message": "Invalid username or password"
#     },
#     "MF-402": {
#       "status": "MFA_ERROR",
#       "message": "Invalid verification code"
#     }
#   }
# }
# EOL
# cat > .cursorrules/test-requirements.json << EOL
# {
#   "auth": {
#     "loginAction": {
#       "requiredTests": [
#         "successful login",
#         "invalid credentials",
#         "MFA required",
#         "email verification required",
#         "network error",
#         "rate limiting"
#       ],
#       "mockRequirements": {
#         "esApi": ["post"],
#         "authLogger": ["logLoginAttempt", "logError"],
#         "encryption": ["encrypt"]
#       }
#     }
#   }
# }
# EOL
# cat > .cursorrules/component-structure.json << EOL
# {
#   "LoginForm": {
#     "requiredProps": ["onSubmit", "onMFARequired", "onEmailVerificationRequired"],
#     "requiredState": ["isLoading", "error"],
#     "requiredHandlers": ["handleSubmit", "handleInputChange"],
#     "accessibility": {
#       "required": ["aria-labels", "error-announcements", "keyboard-navigation"]
#     }
#   },
#   "MFAFlow": {
#     "requiredProps": ["devices", "onVerification"],
#     "requiredComponents": ["DeviceSelection", "OTPInput"],
#     "requiredState": ["selectedDevice", "otpValue", "error"]
#   }
# }
# EOL
# cat > .cursorrules/state-patterns.json << EOL
# {
#   "authStore": {
#     "requiredSlices": ["user", "mfa", "errors"],
#     "requiredActions": ["setUser", "setMFAStatus", "clearErrors"],
#     "persistence": {
#       "required": true,
#       "mechanism": "localStorage",
#       "encryption": true
#     }
#   }
# }
# EOL

# #!/bin/bash

# # Previous setup code...

# # Create enhanced patterns directory

# mkdir -p .cursorrules/patterns

# # Copy all the new pattern files

# cp implementation-patterns.json .cursorrules/patterns/

# cp type-constraints.json .cursorrules/patterns/

# cp function-templates.json .cursorrules/patterns/

# cp response-mapping.json .cursorrules/patterns/

# cp test-requirements.json .cursorrules/patterns/

# cp component-structure.json .cursorrules/patterns/

# cp state-patterns.json .cursorrules/patterns/

# # Update main config to reference new patterns

# cat > .cursorrules/config.json << EOL

# {

#   "version": "1.0",

#   "project": "shared-health-portal",

#   "patterns": {

#     "implementation": "./patterns/implementation-patterns.json",

#     "types": "./patterns/type-constraints.json",

#     "functions": "./patterns/function-templates.json",

#     "responses": "./patterns/response-mapping.json",

#     "testing": "./patterns/test-requirements.json",

#     "components": "./patterns/component-structure.json",

#     "state": "./patterns/state-patterns.json"

#   }

# }

# EOL

# Add state and caching patterns
cat > .cursorrules/patterns/state-management.json << EOL
{
  "authStore": {
    "requiredSlices": {
      "user": {
        "state": ["isAuthenticated", "user", "error"],
        "actions": ["setUser", "clearUser", "setError"]
      },
      "mfa": {
        "state": ["mfaStatus", "mfaDevices", "selectedDevice"],
        "actions": ["setMFAStatus", "setDevices", "selectDevice"]
      },
      "session": {
        "state": ["interactionId", "interactionToken"],
        "actions": ["setInteractionTokens", "clearSession"]
      }
    },
    "persistence": {
      "required": true,
      "mechanism": "localStorage",
      "encryption": true,
      "sensitive": ["interactionToken", "userToken"]
    }
  }
}
EOL

cat > .cursorrules/patterns/cache-strategy.json << EOL
{
  "redis": {
    "keyPatterns": {
      "session": "session:{sessionId}",
      "tokens": "tokens:{userId}",
      "mfaAttempts": "mfa:attempts:{userId}",
      "loginAttempts": "login:attempts:{ip}"
    },
    "ttl": {
      "session": 3600,
      "tokens": 86400,
      "mfaAttempts": 600,
      "loginAttempts": 900
    },
    "structures": {
      "session": {
        "required": ["userId", "esToken", "pingOneToken"],
        "encrypted": ["esToken", "pingOneToken"]
      },
      "tokens": {
        "required": ["accessToken", "refreshToken", "expiresAt"],
        "encrypted": ["accessToken", "refreshToken"]
      }
    },
    "operations": {
      "session": {
        "get": "async (sessionId: string) => Promise<SessionData>",
        "set": "async (sessionId: string, data: SessionData, ttl?: number) => Promise<void>",
        "destroy": "async (sessionId: string) => Promise<void>"
      },
      "rateLimiting": {
        "increment": "async (key: string) => Promise<number>",
        "check": "async (key: string, limit: number) => Promise<boolean>"
      }
    }
  }
}
EOL

cat > .cursorrules/patterns/state-composition.json << EOL
{
  "storeComposition": {
    "auth": {
      "slices": ["user", "mfa", "session"],
      "middleware": ["logger", "persistence", "encryption"]
    }
  },
  "actionPatterns": {
    "login": {
      "sequence": [
        "clearPreviousSession",
        "validateCredentials",
        "authenticateWithES",
        "handleMFARequirement",
        "establishSession",
        "persistState"
      ]
    },
    "mfa": {
      "sequence": [
        "validateCurrentSession",
        "selectDevice",
        "validateOTP",
        "updateSession",
        "persistState"
      ]
    }
  }
}
EOL

# Add templates for state implementation
cat > .cursorrules/templates/state-store.ts << EOL
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { encrypt, decrypt } from '@/utils/encryption';

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  mfaStatus: MFAStatus;
  mfaDevices: MFADevice[];
  interactionId?: string;
  interactionToken?: string;
  error: string | null;
}

interface AuthActions {
  setUser: (user: User | null) => void;
  setMFAStatus: (status: MFAStatus) => void;
  setMFADevices: (devices: MFADevice[]) => void;
  setInteractionTokens: (tokens: { interactionId: string; interactionToken: string }) => void;
  clearSession: () => void;
  setError: (error: string | null) => void;
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  mfaStatus: 'idle',
  mfaDevices: [],
  error: null
};

export const useAuthStore = create<AuthState & AuthActions>()(
  persist(
    (set) => ({
      ...initialState,

      setUser: (user) => set({ user, isAuthenticated: !!user }),
      
      setMFAStatus: (mfaStatus) => set({ mfaStatus }),
      
      setMFADevices: (mfaDevices) => set({ mfaDevices }),
      
      setInteractionTokens: (tokens) => set({ 
        interactionId: tokens.interactionId,
        interactionToken: encrypt(tokens.interactionToken)
      }),
      
      clearSession: () => set(initialState),
      
      setError: (error) => set({ error })
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);
EOL

# Add templates for Redis cache implementation
cat > .cursorrules/templates/redis-cache.ts << EOL
import { Redis } from '@upstash/redis';
import { encrypt, decrypt } from '@/utils/encryption';

const redis = new Redis({
  url: process.env.REDIS_URL!,
  token: process.env.REDIS_TOKEN!
});

export const sessionStore = {
  async get(sessionId: string): Promise<SessionData | null> {
    const data = await redis.get(`session:${sessionId}`);
    if (!data) return null;
    return {
      ...data,
      esToken: decrypt(data.esToken),
      pingOneToken: decrypt(data.pingOneToken)
    };
  },

  async set(sessionId: string, data: SessionData): Promise<void> {
    await redis.set(
      `session:${sessionId}`,
      {
        ...data,
        esToken: encrypt(data.esToken),
        pingOneToken: encrypt(data.pingOneToken)
      },
      {
        ex: 3600 // 1 hour expiry
      }
    );
  },

  async destroy(sessionId: string): Promise<void> {
    await redis.del(`session:${sessionId}`);
  }
};

export const rateLimiter = {
  async checkLoginAttempts(ip: string): Promise<boolean> {
    const attempts = await redis.incr(`login:attempts:${ip}`);
    if (attempts === 1) {
      await redis.expire(`login:attempts:${ip}`, 900); // 15 minutes
    }
    return attempts <= 5;
  },

  async checkMFAAttempts(userId: string): Promise<boolean> {
    const attempts = await redis.incr(`mfa:attempts:${userId}`);
    if (attempts === 1) {
      await redis.expire(`mfa:attempts:${userId}`, 600); // 10 minutes
    }
    return attempts <= 3;
  }
};
EOL

# Update main config to include state and caching patterns
cat > .cursorrules/config.json << EOL
{
  "version": "1.0",
  "project": "shared-health-portal",
  "semanticPatterns": {
    "flows": "./patterns/core-flows.json",
    "types": "./patterns/type-validation.json",
    "functions": "./patterns/function-templates.json",
    "responses": "./patterns/response-mapping.json",
    "state": "./patterns/state-management.json",
    "cache": "./patterns/cache-strategy.json",
    "stateComposition": "./patterns/state-composition.json"
  },
  "contextRules": {
    "auth": {
      "patterns": [
        "src/app/(auth)/**/*",
        "src/components/auth/**/*"
      ],
      "constraints": {
        "requireCorrelationId": true,
        "requireErrorHandling": true,
        "requireValidation": true,
        "requireLogging": true,
        "requireStateManagement": true,
        "requireCaching": true
      }
    }
  }
}
EOL

echo "Added state management and caching patterns!"