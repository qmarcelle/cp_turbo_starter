import axios, { AxiosError, AxiosInstance } from 'axios';
import { authLogger } from '../logging/auth-logger';
import { getAuthToken } from './getToken';
import { v4 as uuidv4 } from 'uuid';

interface ApiError {
  code: string;
  message: string;
  correlationId: string;
}

interface ApiErrorResponse {
  message: string;
  [key: string]: unknown;
}

class ESApiClient {
  private client: AxiosInstance;
  
  constructor() {
    this.client = axios.create({
      baseURL: process.env.ES_API_URL,
      proxy: process.env.NEXT_PUBLIC_PROXY?.toLowerCase() === 'false' ? false : undefined,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    this.client.interceptors.request.use(
      async (config) => {
        try {
          // Generate correlation ID for request tracking
          const correlationId = uuidv4();
          config.headers['X-Correlation-ID'] = correlationId;

          if (config.data) {
            config.data.credentials = process.env.ES_API_PING_CREDENTIALS
              ? btoa(process.env.ES_API_PING_CREDENTIALS)
              : undefined;
          }
          const token = await getAuthToken();
          if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
          }

          // Log outgoing request
          authLogger.info('API Request', { 
            url: config.url,
            method: config.method,
            correlationId
          });
        } catch (error) {
          authLogger.error('GetAuthToken API - Failure', error as Error);
        }
        return config;
      },
      (error) => {
        authLogger.error('Request Interceptor Error', error);
        return Promise.reject(error);
      }
    );

    this.client.interceptors.response.use(
      (response) => {
        const correlationId = response.config.headers['X-Correlation-ID'];
        authLogger.info('API Response Success', { 
          url: response.config.url,
          correlationId
        });
        return response.data;
      },
      (error: AxiosError<ApiErrorResponse>) => this.handleApiError(error)
    );
  }

  private handleApiError(error: AxiosError<ApiErrorResponse>): never {
    const correlationId = error.config?.headers?.['X-Correlation-ID'] as string;
    
    const apiError: ApiError = {
      code: 'API_ERROR',
      message: 'An unexpected error occurred',
      correlationId: correlationId || 'unknown',
    };

    if (error.response) {
      apiError.code = `HTTP_${error.response.status}`;
      apiError.message = error.response.data?.message || error.message;
    } else if (error.request) {
      apiError.code = 'NETWORK_ERROR';
      apiError.message = 'Network error occurred';
    }

    authLogger.error('API Request Failed', error, { 
      error: apiError,
      correlationId
    });
    throw apiError;
  }

  async get<T>(url: string): Promise<T> {
    const response = await this.client.get<T>(url);
    return response.data;
  }

  async post<T>(url: string, data: unknown): Promise<T> {
    const response = await this.client.post<T>(url, data);
    return response.data;
  }

  async put<T>(url: string, data: unknown): Promise<T> {
    const response = await this.client.put<T>(url, data);
    return response.data;
  }

  async delete<T>(url: string): Promise<T> {
    const response = await this.client.delete<T>(url);
    return response.data;
  }
}

export const esApi = new ESApiClient(); 