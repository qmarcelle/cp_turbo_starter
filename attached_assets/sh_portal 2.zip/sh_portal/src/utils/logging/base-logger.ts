import { v4 as uuidv4 } from 'uuid';

interface LogMetadata {
  correlationId: string;
  service: string;
  component: string;
  environment: string;
  timestamp?: string;
  [key: string]: unknown;
}

type LogLevel = 'error' | 'warn' | 'info' | 'debug';

const MASKED_FIELDS = ['password', 'token', 'sessionId', 'mfaCode'];
const MASK_PATTERN = '****';

class BaseLogger {
  private isServer: boolean;

  constructor() {
    this.isServer = typeof window === 'undefined';
  }

  private maskSensitiveData<T extends Record<string, unknown>>(data: T): T {
    const masked = { ...data };
    for (const key in masked) {
      if (MASKED_FIELDS.includes(key.toLowerCase())) {
        masked[key] = MASK_PATTERN;
      } else if (typeof masked[key] === 'object' && masked[key] !== null) {
        masked[key] = this.maskSensitiveData(masked[key] as Record<string, unknown>);
      }
    }
    return masked;
  }

  private formatMetadata(metadata: Partial<LogMetadata> = {}): LogMetadata {
    return {
      correlationId: metadata.correlationId || uuidv4(),
      service: metadata.service || process.env.SERVICE_NAME || 'unknown',
      component: metadata.component || 'unknown',
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString(),
      ...metadata
    };
  }

  private formatLogMessage(level: LogLevel, message: string, metadata: Record<string, unknown>): string {
    return JSON.stringify({
      level,
      message,
      ...metadata,
      timestamp: new Date().toISOString()
    });
  }

  log(level: LogLevel, message: string, metadata: Partial<LogMetadata> = {}): string {
    const formattedMetadata = this.formatMetadata(metadata);
    const maskedMetadata = this.maskSensitiveData(formattedMetadata);
    const logMessage = this.formatLogMessage(level, message, maskedMetadata);

    if (this.isServer) {
      // Server-side logging
      switch (level) {
        case 'error':
          console.error(logMessage);
          break;
        case 'warn':
          console.warn(logMessage);
          break;
        case 'info':
          console.info(logMessage);
          break;
        case 'debug':
          console.debug(logMessage);
          break;
      }
    } else {
      // Client-side logging (only in development)
      if (process.env.NODE_ENV === 'development') {
        switch (level) {
          case 'error':
            console.error(logMessage);
            break;
          case 'warn':
            console.warn(logMessage);
            break;
          case 'info':
            console.info(logMessage);
            break;
          case 'debug':
            console.debug(logMessage);
            break;
        }
      }
    }

    return formattedMetadata.correlationId;
  }

  error(message: string, metadata: Partial<LogMetadata> = {}, error?: Error): string {
    const errorMetadata = {
      ...metadata,
      error: error ? {
        message: error.message,
        stack: error.stack,
        name: error.name
      } : undefined
    };
    return this.log('error', message, errorMetadata);
  }

  warn(message: string, metadata: Partial<LogMetadata> = {}): string {
    return this.log('warn', message, metadata);
  }

  info(message: string, metadata: Partial<LogMetadata> = {}): string {
    return this.log('info', message, metadata);
  }

  debug(message: string, metadata: Partial<LogMetadata> = {}): string {
    return this.log('debug', message, metadata);
  }

  createContext(correlationId?: string): Partial<LogMetadata> {
    return {
      correlationId: correlationId || uuidv4()
    };
  }
}

export const baseLogger = new BaseLogger(); 