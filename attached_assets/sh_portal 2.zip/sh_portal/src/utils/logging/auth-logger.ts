import { baseLogger } from './base-logger';

interface AuthContext {
  correlationId: string;
  username?: string;
  deviceType?: string;
  ipAddress?: string;
  userAgent?: string;
}

class AuthLogger {
  private component = 'auth';

  private createAuthMetadata(context: Partial<AuthContext> = {}) {
    return {
      ...baseLogger.createContext(context.correlationId),
      component: this.component,
      ...context
    };
  }

  // Login Events
  logLoginAttempt(context: AuthContext) {
    return baseLogger.info('Login attempt', {
      ...this.createAuthMetadata(context),
      action: 'login:attempt'
    });
  }

  logLoginSuccess(context: AuthContext) {
    return baseLogger.info('Login successful', {
      ...this.createAuthMetadata(context),
      action: 'login:success'
    });
  }

  logLoginFailure(context: AuthContext, reason: string, attempts: number) {
    return baseLogger.warn('Login failed', {
      ...this.createAuthMetadata(context),
      action: 'login:failure',
      reason,
      attempts
    });
  }

  // MFA Events
  logMFADeviceSelection(context: AuthContext) {
    return baseLogger.info('MFA device selected', {
      ...this.createAuthMetadata(context),
      action: 'mfa:device_selection'
    });
  }

  logMFAVerificationAttempt(context: AuthContext) {
    return baseLogger.info('MFA verification attempt', {
      ...this.createAuthMetadata(context),
      action: 'mfa:verification:attempt'
    });
  }

  logMFAVerificationSuccess(context: AuthContext) {
    return baseLogger.info('MFA verification successful', {
      ...this.createAuthMetadata(context),
      action: 'mfa:verification:success'
    });
  }

  logMFAVerificationFailure(context: AuthContext, reason: string, attempts: number) {
    return baseLogger.warn('MFA verification failed', {
      ...this.createAuthMetadata(context),
      action: 'mfa:verification:failure',
      reason,
      attempts
    });
  }

  // Error Events
  logError(error: Error, action: string, context: Partial<AuthContext> = {}) {
    return baseLogger.error('Auth error occurred', {
      ...this.createAuthMetadata(context),
      action: `error:${action}`
    }, error);
  }

  // Audit Events
  logAudit(action: string, context: Partial<AuthContext>, message: string) {
    return baseLogger.info(message, {
      ...this.createAuthMetadata(context),
      action: `audit:${action}`
    });
  }

  info(message: string, metadata: Partial<AuthContext> = {}) {
    return baseLogger.info(message, this.createAuthMetadata(metadata));
  }

  error(message: string, metadata: Partial<AuthContext> = {}, error?: Error) {
    return baseLogger.error(message, this.createAuthMetadata(metadata), error);
  }
}

export const authLogger = new AuthLogger(); 