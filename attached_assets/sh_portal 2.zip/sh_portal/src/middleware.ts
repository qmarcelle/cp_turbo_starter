// @src/middleware.ts
import {auth} from "./auth"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
 
export async function middleware(request: NextRequest) {
  const session = await auth();
 
  // Check if user needs to complete MFA
  const mfaRequired = request.cookies.get('mfa_required');
  if (mfaRequired) {
    return NextResponse.redirect(new URL('/auth/mfa', request.url));
  }
 
  if (!session) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
}
 
export const config = {
  matcher: ['/((?!api|_next/static|_next/image|login|favicon.ico).*)']
}