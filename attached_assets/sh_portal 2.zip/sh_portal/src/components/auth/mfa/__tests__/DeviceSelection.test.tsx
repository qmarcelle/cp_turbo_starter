import React from 'react';
import { render, screen, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { DeviceSelection } from '../DeviceSelection';

// Mock the auth store
const mockSetLoading = jest.fn();
const defaultMockStore = {
  isLoading: false,
  setLoading: mockSetLoading,
};

jest.mock('@/lib/store/auth', () => ({
  useAuthStore: () => defaultMockStore,
}));

describe('DeviceSelection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders all delivery method options', () => {
    render(<DeviceSelection />);
    
    expect(screen.getByText('Use an Authenticator App')).toBeInTheDocument();
    expect(screen.getByText(/Text a code to/)).toBeInTheDocument();
    expect(screen.getByText(/Call with a code to/)).toBeInTheDocument();
    expect(screen.getByText(/Email a code to/)).toBeInTheDocument();
  });

  it('enables send button only when a method is selected', async () => {
    const user = userEvent.setup();
    render(<DeviceSelection />);
    
    const sendButton = screen.getByRole('button', { name: 'Send Code' });
    expect(sendButton).toBeDisabled();

    const smsOption = screen.getByLabelText(/Text a code to/);
    await act(async () => {
      await user.click(smsOption);
    });
    
    expect(sendButton).toBeEnabled();
  });

  it('shows loading state during submission', async () => {
    const user = userEvent.setup();
    render(<DeviceSelection />);
    
    const smsOption = screen.getByLabelText(/Text a code to/);
    await act(async () => {
      await user.click(smsOption);
    });
    
    const sendButton = screen.getByRole('button', { name: 'Send Code' });
    await act(async () => {
      await user.click(sendButton);
    });
    
    expect(mockSetLoading).toHaveBeenCalledWith(true);
  });
}); 