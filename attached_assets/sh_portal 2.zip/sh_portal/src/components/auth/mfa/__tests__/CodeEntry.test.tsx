import React from 'react';
import { render, screen, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { CodeEntry } from '../CodeEntry';

// Mock the auth store
const mockSetLoading = jest.fn();
const defaultMockStore = {
  isLoading: false,
  setLoading: mockSetLoading,
};

jest.mock('@/lib/store/auth', () => ({
  useAuthStore: () => defaultMockStore,
}));

describe('CodeEntry', () => {
  const mockProps = {
    deliveryMethod: 'sms' as const,
    maskedDestination: '(***) ***-7890',
    onResend: jest.fn().mockResolvedValue(undefined),
    onChangeMethod: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockProps.onResend.mockClear();
    mockProps.onChangeMethod.mockClear();
  });

  it('renders code entry form with masked destination', () => {
    render(<CodeEntry {...mockProps} />);
    
    const text = screen.getByText(/We've sent a code to:.*\(\*\*\*\) \*\*\*-7890/);
    expect(text).toBeInTheDocument();
  });

  it('shows validation error for empty code', async () => {
    const user = userEvent.setup();
    render(<CodeEntry {...mockProps} />);
    
    const submitButton = screen.getByRole('button', { name: 'Confirm' });
    await act(async () => {
      await user.click(submitButton);
    });
    
    const errorMessage = screen.getByRole('alert');
    expect(errorMessage).toHaveTextContent('Please enter the security code');
  });

  it('handles code verification', async () => {
    const user = userEvent.setup();
    render(<CodeEntry {...mockProps} />);
    
    const input = screen.getByLabelText('Enter Security Code');
    await act(async () => {
      await user.type(input, '123456');
    });
    
    const submitButton = screen.getByRole('button', { name: 'Confirm' });
    await act(async () => {
      await user.click(submitButton);
    });
    
    expect(mockSetLoading).toHaveBeenCalledWith(true);
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });

  it('handles resend functionality', async () => {
    const user = userEvent.setup();
    render(<CodeEntry {...mockProps} />);
    
    const resendButton = screen.getByRole('button', { name: 'Resend Code' });
    await act(async () => {
      await user.click(resendButton);
    });
    
    expect(mockProps.onResend).toHaveBeenCalled();
  });

  it('handles method change', async () => {
    const user = userEvent.setup();
    render(<CodeEntry {...mockProps} />);
    
    const changeMethodButton = screen.getByRole('button', { name: 'Choose a Different Method' });
    await act(async () => {
      await user.click(changeMethodButton);
    });
    
    expect(mockProps.onChangeMethod).toHaveBeenCalled();
  });

  it('shows different instructions for authenticator app', () => {
    render(
      <CodeEntry
        {...mockProps}
        deliveryMethod="authenticator"
        maskedDestination=""
      />
    );
    
    expect(screen.getByText('Enter the security code from your authenticator app.')).toBeInTheDocument();
  });
}); 