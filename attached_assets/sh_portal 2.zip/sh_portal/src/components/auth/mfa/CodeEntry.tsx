import React, { useState, useCallback } from 'react';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';
import { useAuthStore } from '@/lib/store/auth';

interface CodeEntryProps {
  deliveryMethod: 'authenticator' | 'sms' | 'call' | 'email';
  maskedDestination: string;
  onResend: () => Promise<void>;
  onChangeMethod: () => void;
}

export const CodeEntry: React.FC<CodeEntryProps> = ({
  deliveryMethod,
  maskedDestination,
  onResend,
  onChangeMethod,
}) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState<string>();
  const { isLoading, setLoading } = useAuthStore();

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code) {
      setError('Please enter the security code');
      return;
    }

    try {
      // Batch state updates
      React.startTransition(() => {
        setError(undefined);
        setLoading(true);
      });

      // TODO: Implement verification logic
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (code !== '123456') { // Mock validation
        throw new Error('Invalid security code');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed');
    } finally {
      setLoading(false);
    }
  }, [code, setLoading]);

  const handleResend = useCallback(async () => {
    try {
      setError(undefined);
      await onResend();
    } catch (err) {
      setError('Failed to resend code');
    }
  }, [onResend]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    // Batch state updates
    React.startTransition(() => {
      setCode(newValue);
      if (error) {
        setError(undefined);
      }
    });
  }, [error]);

  const getDeliveryText = useCallback(() => {
    switch (deliveryMethod) {
      case 'authenticator':
        return 'Enter the security code from your authenticator app.';
      case 'sms':
      case 'email':
      case 'call':
        return `We've sent a code to: ${maskedDestination}`;
    }
  }, [deliveryMethod, maskedDestination]);

  return (
    <div className="bg-white rounded-lg p-8 max-w-[440px] mx-auto">
      <div className="mb-6">
        <a
          href="/"
          className="text-[#0066CC] hover:underline flex items-center gap-2 mb-6"
        >
          ← Back to Homepage
        </a>
        <h1 className="text-[28px] font-normal text-[#333333]">
          Enter The Security Code
        </h1>
        <p className="text-[16px] text-[#333333] mt-4">
          {getDeliveryText()}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Input
          id="security-code"
          name="code"
          label="Enter Security Code"
          value={code}
          onChange={handleChange}
          error={error}
          disabled={isLoading}
          autoComplete="one-time-code"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={6}
        />

        <Button
          type="submit"
          isLoading={isLoading}
          loadingText="Verifying..."
          className="w-full"
        >
          Confirm
        </Button>

        <div className="flex flex-col items-center gap-4 pt-4">
          <button
            type="button"
            onClick={handleResend}
            className="text-[#0066CC] hover:underline text-sm"
            disabled={isLoading}
          >
            Resend Code
          </button>

          <button
            type="button"
            onClick={onChangeMethod}
            className="text-[#0066CC] hover:underline text-sm"
            disabled={isLoading}
          >
            Choose a Different Method
          </button>
        </div>

        <div className="pt-4 border-t">
          <h2 className="font-medium mb-2">Need help?</h2>
          <p className="text-sm text-gray-600">
            Give us a call using the number listed on the back of your Member ID card or{' '}
            <a href="/contact" className="text-[#0066CC] hover:underline">
              contact us
            </a>
            .
          </p>
        </div>
      </form>
    </div>
  );
}; 