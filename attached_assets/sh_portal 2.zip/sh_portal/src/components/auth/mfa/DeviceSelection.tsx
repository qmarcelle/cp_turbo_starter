import React, { useState } from 'react';
import { Button } from '../../ui/Button';
import { useAuthStore } from '@/lib/store/auth';

interface Device {
  id: string;
  type: 'authenticator' | 'sms' | 'call' | 'email';
  value: string;
  label: string;
}

export const DeviceSelection: React.FC = () => {
  const [selectedDevice, setSelectedDevice] = useState<string>('');
  const { setLoading, isLoading } = useAuthStore();

  const devices: Device[] = [
    {
      id: 'authenticator',
      type: 'authenticator',
      value: 'authenticator',
      label: 'Use an Authenticator App'
    },
    {
      id: 'sms',
      type: 'sms',
      value: '(***) ***-7890',
      label: 'Text a code to'
    },
    {
      id: 'call',
      type: 'call',
      value: '(***) ***-0110',
      label: 'Call with a code to'
    },
    {
      id: 'email',
      type: 'email',
      value: 'c*******@gmail.com',
      label: 'Email a code to'
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDevice) return;

    setLoading(true);
    try {
      // TODO: Implement send code logic
      await new Promise(resolve => setTimeout(resolve, 1000));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg p-8 max-w-[440px] mx-auto">
      <div className="mb-6">
        <a
          href="/"
          className="text-[#0066CC] hover:underline flex items-center gap-2 mb-6"
        >
          ← Back to Homepage
        </a>
        <h1 className="text-[28px] font-normal text-[#333333]">
          Let's Confirm Your Identity
        </h1>
        <p className="text-[16px] text-[#333333] mt-4">
          How would you like to receive your security code?
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4" role="radiogroup">
          {devices.map((device) => (
            <label
              key={device.id}
              className={`
                flex items-center p-4 border rounded-lg cursor-pointer
                ${selectedDevice === device.id ? 'border-[#0066CC]' : 'border-gray-300'}
              `}
            >
              <input
                type="radio"
                name="mfa-device"
                value={device.id}
                checked={selectedDevice === device.id}
                onChange={(e) => setSelectedDevice(e.target.value)}
                className="mr-3"
                aria-label={`${device.label} ${device.value}`}
              />
              <div>
                <div className="font-medium">{device.label}</div>
                {device.type !== 'authenticator' && (
                  <div className="text-gray-600 text-sm">{device.value}</div>
                )}
              </div>
            </label>
          ))}
        </div>

        <Button
          type="submit"
          disabled={!selectedDevice || isLoading}
          className={`w-full ${isLoading ? 'opacity-50' : ''}`}
        >
          Send Code
        </Button>

        <p className="text-sm text-gray-600 mt-4">
          By sending the code, I agree to receive a one-time message.
          Message and data rates may apply. Subject to terms and
          condition.
        </p>
      </form>
    </div>
  );
}; 