import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { LoginForm } from '../LoginForm';
import { useAuth } from '@/lib/hooks/useAuth';

// Mock the useAuth hook
jest.mock('@/lib/hooks/useAuth');
const mockUseAuth = useAuth as jest.Mock;

describe('LoginForm', () => {
  // Rendering Tests
  describe('rendering', () => {
    beforeEach(() => {
      mockUseAuth.mockReturnValue({
        login: jest.fn(),
        isLoading: false,
        error: null
      });
    });

    it('renders all form elements', () => {
      render(<LoginForm />);
      
      expect(screen.getByLabelText(/username/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /sign in/i })).toBeInTheDocument();
    });

    it('applies proper styling', () => {
      render(<LoginForm />);
      
      const form = screen.getByRole('form');
      expect(form).toHaveClass('space-y-6');
      
      const inputs = screen.getAllByRole('textbox');
      inputs.forEach(input => {
        expect(input).toHaveClass('form-input');
      });
    });

    it('shows error message when present', () => {
      mockUseAuth.mockReturnValue({
        login: jest.fn(),
        isLoading: false,
        error: 'Invalid credentials'
      });

      render(<LoginForm />);
      expect(screen.getByRole('alert')).toHaveTextContent('Invalid credentials');
    });
  });

  // Validation Tests
  describe('validation', () => {
    const mockLogin = jest.fn();
    
    beforeEach(() => {
      mockUseAuth.mockReturnValue({
        login: mockLogin,
        isLoading: false,
        error: null
      });
    });

    it('requires username', async () => {
      render(<LoginForm />);
      
      await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
      expect(screen.getByText('Username is required')).toBeInTheDocument();
    });

    it('requires minimum username length', async () => {
      render(<LoginForm />);
      
      await userEvent.type(screen.getByLabelText(/username/i), 'ab');
      await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
      expect(screen.getByText('Username must be at least 3 characters')).toBeInTheDocument();
    });

    it('requires password', async () => {
      render(<LoginForm />);
      
      await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
      expect(screen.getByText('Password is required')).toBeInTheDocument();
    });

    it('requires minimum password length', async () => {
      render(<LoginForm />);
      
      await userEvent.type(screen.getByLabelText(/password/i), 'short');
      await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
      expect(screen.getByText('Password must be at least 8 characters')).toBeInTheDocument();
    });
  });

  // Interaction Tests
  describe('interactions', () => {
    const mockLogin = jest.fn();
    
    beforeEach(() => {
      mockLogin.mockClear();
      mockUseAuth.mockReturnValue({
        login: mockLogin,
        isLoading: false,
        error: null
      });
    });

    it('handles successful submission', async () => {
      render(<LoginForm />);
      
      await userEvent.type(screen.getByLabelText(/username/i), 'validUser');
      await userEvent.type(screen.getByLabelText(/password/i), 'validPass123');
      await userEvent.click(screen.getByRole('button', { name: /sign in/i }));

      expect(mockLogin).toHaveBeenCalledWith('validUser', 'validPass123');
    });

    it('shows loading state during submission', async () => {
      mockUseAuth.mockReturnValue({
        login: mockLogin,
        isLoading: true,
        error: null
      });

      render(<LoginForm />);
      const submitButton = screen.getByRole('button', { name: /sign in/i });
      expect(submitButton).toBeDisabled();
      expect(submitButton).toHaveClass('cursor-not-allowed');
    });

    it('handles submission errors', async () => {
      mockUseAuth.mockReturnValue({
        login: mockLogin,
        isLoading: false,
        error: 'Invalid credentials'
      });

      render(<LoginForm />);
      expect(screen.getByRole('alert')).toHaveTextContent('Invalid credentials');
    });
  });

  // Accessibility Tests
  describe('accessibility', () => {
    beforeEach(() => {
      mockUseAuth.mockReturnValue({
        login: jest.fn(),
        isLoading: false,
        error: null
      });
    });

    it('has proper form labeling', () => {
      render(<LoginForm />);
      
      expect(screen.getByLabelText(/username/i)).toHaveAttribute('aria-required', 'true');
      expect(screen.getByLabelText(/password/i)).toHaveAttribute('aria-required', 'true');
    });

    it('manages focus correctly', async () => {
      render(<LoginForm />);
      
      const username = screen.getByLabelText(/username/i);
      const password = screen.getByLabelText(/password/i);
      const submit = screen.getByRole('button', { name: /sign in/i });

      expect(document.body).toHaveFocus();
      
      await userEvent.tab();
      expect(username).toHaveFocus();
      
      await userEvent.tab();
      expect(password).toHaveFocus();
      
      await userEvent.tab();
      expect(submit).toHaveFocus();
    });

    it('announces errors to screen readers', async () => {
      mockUseAuth.mockReturnValue({
        login: jest.fn(),
        isLoading: false,
        error: 'Invalid credentials'
      });

      render(<LoginForm />);
      const alert = screen.getByRole('alert');
      expect(alert).toHaveAttribute('aria-live', 'polite');
    });
  });
}); 