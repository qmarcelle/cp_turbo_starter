'use client';

import React, { useState, FormEvent } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/lib/store/auth';

interface LoginFormData {
  username: string;
  password: string;
}

interface FormErrors {
  username?: string;
  password?: string;
  general?: string;
}

export const LoginForm: React.FC = () => {
  const router = useRouter();
  const [formData, setFormData] = useState<LoginFormData>({
    username: '',
    password: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const { isLoading, setLoading } = useAuthStore();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: undefined, general: undefined }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const newErrors: FormErrors = {};

    if (!formData.username) {
      newErrors.username = 'Please fill in all fields';
    } else if (formData.username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    }

    if (!formData.password) {
      newErrors.password = 'Please fill in all fields';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    try {
      const result = await signIn('credentials', {
        username: formData.username,
        password: formData.password,
        redirect: false,
      });

      if (result?.error === 'MFA_REQUIRED') {
        router.push('/auth/mfa');
        return;
      }

      if (result?.ok) {
        router.push('/dashboard');
      } else {
        setErrors({
          general: result?.error || "We didn't recognize the username or password you entered"
        });
      }
    } catch (err) {
      setErrors({
        general: 'An unexpected error occurred'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg p-8 max-w-[440px] mx-auto">
      <div className="mb-6">
        <a
          href="/"
          className="text-[#0066CC] hover:underline flex items-center gap-2 mb-6"
        >
          ← Back to Homepage
        </a>
        <h1 className="text-[28px] font-normal text-[#333333]">Member Login</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {errors.general && (
          <div 
            className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm"
            role="alert"
          >
            {errors.general}
          </div>
        )}

        <Input
          id="username"
          name="username"
          label="Username"
          value={formData.username}
          onChange={handleChange}
          error={errors.username}
          disabled={isLoading}
          autoComplete="username"
          data-testid="username-input"
        />

        <Input
          id="password"
          name="password"
          type="password"
          label="Password"
          value={formData.password}
          onChange={handleChange}
          error={errors.password}
          disabled={isLoading}
          showPasswordToggle
          autoComplete="current-password"
          data-testid="password-input"
        />

        <Button
          type="submit"
          isLoading={isLoading}
          loadingText="Logging in..."
          className="w-full"
        >
          Log In
        </Button>

        <div className="text-center">
          <a
            href="/forgot-credentials"
            className="text-[#0066CC] hover:underline text-sm"
          >
            Forgot Username/Password?
          </a>
        </div>

        <div className="pt-4 border-t">
          <Button
            variant="secondary"
            className="w-full"
            onClick={() => router.push('/register')}
          >
            Register a New Account
          </Button>
        </div>
      </form>
    </div>
  );
}; 