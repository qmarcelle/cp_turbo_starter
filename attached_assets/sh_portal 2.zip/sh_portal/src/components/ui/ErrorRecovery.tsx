import React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from './Button';
import { ErrorMessage } from './ErrorMessage';

interface ErrorRecoveryProps {
  error: string | null;
  errorCode?: string;
  onRetry?: () => void;
  canRetry?: boolean;
  retryCount?: number;
}

export function ErrorRecovery({ 
  error, 
  errorCode, 
  onRetry, 
  canRetry = false,
  retryCount = 0 
}: ErrorRecoveryProps) {
  const router = useRouter();

  const handleAction = () => {
    if (errorCode === 'SYSTEM_ERROR') {
      router.push('/error');
      return;
    }

    if (errorCode === 'NETWORK_ERROR' && canRetry) {
      onRetry?.();
      return;
    }

    if (errorCode?.startsWith('UI-') || errorCode?.startsWith('MF-')) {
      // Validation errors are displayed inline
      return;
    }

    // Default to retry if handler provided
    if (onRetry) {
      onRetry();
    }
  };

  const getActionText = () => {
    if (errorCode === 'SYSTEM_ERROR') return 'Go to Error Page';
    if (errorCode === 'NETWORK_ERROR' && canRetry) return `Retry (${retryCount}/3)`;
    if (onRetry) return 'Try Again';
    return null;
  };

  const actionText = getActionText();

  return (
    <div className="space-y-4">
      <ErrorMessage error={error} />
      {actionText && (
        <Button
          onClick={handleAction}
          variant="secondary"
          size="sm"
          type="button"
          disabled={!canRetry && errorCode === 'NETWORK_ERROR'}
        >
          {actionText}
        </Button>
      )}
    </div>
  );
} 