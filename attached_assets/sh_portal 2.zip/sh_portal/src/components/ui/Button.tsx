'use client';

import React from 'react';
import { Spinner } from './Spinner';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
  type?: 'button' | 'submit';
  disabled?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      variant = 'primary',
      size = 'md',
      type = 'button',
      disabled,
      onClick,
      className = '',
      ...props
    },
    ref
  ) => {
    const baseStyles = 'rounded-md py-3 font-medium inline-flex items-center justify-center min-w-[120px] transition-colors duration-200';
    
    const variants = {
      primary: 'bg-[#0066CC] text-white hover:bg-[#0052A3] disabled:bg-[#B3D1F0]',
      secondary: 'bg-[#8BB4E7] text-white hover:bg-[#7AA3D6] disabled:bg-[#D1E0F5]'
    };

    return (
      <button
        ref={ref}
        className={`
          ${baseStyles}
          ${variants[variant]}
          ${disabled ? 'cursor-not-allowed' : ''}
          ${className}
        `}
        disabled={disabled}
        type={type}
        onClick={onClick}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button'; 