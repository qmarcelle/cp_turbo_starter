import React from 'react';
import { ExclamationCircleIcon } from '@heroicons/react/24/outline';

interface ErrorMessageProps {
  error: string | null;
  testId?: string;
}

export function ErrorMessage({ error, testId = 'error-message' }: ErrorMessageProps) {
  if (!error) return null;

  return (
    <div 
      className="flex items-center text-red-500 mt-2"
      role="alert"
      aria-live="polite"
      data-testid={testId}
    >
      <ExclamationCircleIcon className="mr-2 h-4 w-4" />
      <span className="text-sm">{error}</span>
    </div>
  );
} 