import { LoginForm } from '@/components/auth/login/LoginForm';

export const metadata = {
  title: 'Login - Shared Health Portal',
  description: 'Log in to your Shared Health Portal account',
};

export default function LoginPage() {
  return <LoginForm />;
}
