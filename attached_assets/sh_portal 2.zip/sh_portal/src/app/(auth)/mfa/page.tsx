import { DeviceSelection } from '@/components/auth/mfa/DeviceSelection';

export const metadata = {
  title: 'Two-Factor Authentication - Shared Health Portal',
  description: 'Complete two-factor authentication',
};

export default function MFAPage() {
  return <DeviceSelection />;
} 