import { NextResponse } from 'next/server';

const TEST_USERS = [
  {
    username: 'user@example.com',
    password: 'password123',
    userToken: 'user-123',
    requiresMfa: true,
    devices: [
      { id: 'sms-1', type: 'sms', value: '(***) ***-7890' },
      { id: 'auth-1', type: 'authenticator', value: 'Google Authenticator' }
    ]
  },
  {
    username: 'admin@example.com',
    password: 'admin123',
    userToken: 'admin-456',
    requiresMfa: false
  }
];

export async function POST(request: Request) {
  const body = await request.json();
  const { username, password } = body;

  const user = TEST_USERS.find(u => u.username === username);

  if (!user || user.password !== password) {
    return NextResponse.json(
      { status: 'ERROR', message: 'Invalid credentials' },
      { status: 401 }
    );
  }

  if (user.requiresMfa) {
    return NextResponse.json({
      status: 'MFA_REQUIRED',
      userToken: user.userToken,
      accessToken: `temp-token-${user.userToken}`,
      interactionId: 'int-123',
      interactionToken: 'int-token-456',
      requiresMfa: true,
      devices: user.devices
    });
  }

  return NextResponse.json({
    status: 'SUCCESS',
    userToken: user.userToken,
    accessToken: `token-${user.userToken}`,
    requiresMfa: false
  });
} 