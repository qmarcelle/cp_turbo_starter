import { NextResponse } from 'next/server';

const VALID_CODE = '123456';

export async function POST(request: Request) {
  const body = await request.json();
  const { code, interactionToken } = body;

  if (!interactionToken) {
    return NextResponse.json(
      { status: 'ERROR', message: 'Invalid interaction token' },
      { status: 401 }
    );
  }

  if (code !== VALID_CODE) {
    return NextResponse.json(
      { status: 'ERROR', message: 'Invalid code' },
      { status: 401 }
    );
  }

  return NextResponse.json({
    status: 'SUCCESS',
    accessToken: 'mfa-verified-token-123',
    requiresMfa: false
  });
} 