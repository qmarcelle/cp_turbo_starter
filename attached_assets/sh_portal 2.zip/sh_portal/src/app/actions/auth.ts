import { cookies } from 'next/headers';
import { esApi } from '@/utils/api/esApi';
import { authLogger } from '@/utils/logging/auth-logger';
import { headers } from 'next/headers';

interface LoginRequest {
  username: string;
  password: string;
}

interface LoginResponse {
  sessionToken?: string;
  mfaRequired: boolean;
  deviceList?: Array<{
    id: string;
    name: string;
    type: string;
  }>;
  error?: string;
}

interface MFADeviceSelectionRequest {
  sessionToken: string;
  deviceId: string;
}

interface MFAVerificationRequest {
  sessionToken: string;
  deviceId: string;
  code: string;
}

interface AuthResponse {
  accessToken?: string;
  refreshToken?: string;
  error?: string;
}

function getRequestContext(username?: string) {
  const headersList = headers();
  return {
    correlationId: headersList.get('x-correlation-id') || crypto.randomUUID(),
    username,
    ipAddress: headersList.get('x-forwarded-for') || 'unknown',
    userAgent: headersList.get('user-agent') || 'unknown'
  };
}

export async function login(credentials: LoginRequest): Promise<LoginResponse> {
  const context = getRequestContext(credentials.username);
  authLogger.logLoginAttempt(context);

  try {
    const response = await esApi.post<LoginResponse>('/auth/login', credentials);
    
    if (response.sessionToken) {
      cookies().set('sessionToken', response.sessionToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 3600 // 1 hour
      });
      authLogger.logLoginSuccess(context);
    }

    return response;
  } catch (error: any) {
    authLogger.logLoginFailure(context, error.message, 1);
    return {
      mfaRequired: false,
      error: error.message || 'Login failed'
    };
  }
}

export async function selectMFADevice(request: MFADeviceSelectionRequest): Promise<AuthResponse> {
  const context = getRequestContext();
  context.deviceType = request.deviceId;
  
  try {
    const response = await esApi.post<AuthResponse>('/auth/mfa/select-device', request);
    authLogger.logMFADeviceSelection(context);
    return response;
  } catch (error: any) {
    authLogger.logError(error, 'mfa_device_selection', context);
    return {
      error: error.message || 'Device selection failed'
    };
  }
}

export async function verifyMFACode(request: MFAVerificationRequest): Promise<AuthResponse> {
  const context = getRequestContext();
  context.deviceType = request.deviceId;
  
  authLogger.logMFAVerificationAttempt(context);

  try {
    const response = await esApi.post<AuthResponse>('/auth/mfa/verify', request);
    
    if (response.accessToken && response.refreshToken) {
      cookies().set('accessToken', response.accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 3600 // 1 hour
      });
      
      cookies().set('refreshToken', response.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 3600 // 7 days
      });

      authLogger.logMFAVerificationSuccess(context);
    }

    return response;
  } catch (error: any) {
    authLogger.logMFAVerificationFailure(context, error.message, 1);
    return {
      error: error.message || 'Code verification failed'
    };
  }
}

export async function logout(): Promise<void> {
  const context = getRequestContext();
  
  try {
    await esApi.post('/auth/logout', {});
    
    cookies().delete('sessionToken');
    cookies().delete('accessToken');
    cookies().delete('refreshToken');
    
    authLogger.logAudit('logout', context, 'User logged out successfully');
  } catch (error: any) {
    authLogger.logError(error, 'logout', context);
    throw error;
  }
} 