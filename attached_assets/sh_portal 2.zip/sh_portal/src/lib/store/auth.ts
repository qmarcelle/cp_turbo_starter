'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { tokenManager } from '../auth/token';
import { authLogger } from '../../utils/logging/auth-logger';

interface User {
  id: string;
  email: string;
  name: string;
  preferences?: {
    mfaPreferredDevice?: string;
    notifications?: boolean;
  };
}

interface MFAState {
  isRequired: boolean;
  deviceId?: string;
  verificationId?: string;
  deviceList?: Array<{
    id: string;
    name: string;
    type: string;
  }>;
  attempts: number;
  lastAttemptTime?: string;
}

interface AuthError {
  code: string;
  message: string;
  timestamp: string;
  context?: Record<string, unknown>;
}

interface SessionState {
  lastActive: string;
  expiresAt?: string;
  isValid: boolean;
  deviceId?: string;
}

interface AuthState {
  user: User | null;
  mfa: MFAState;
  errors: AuthError[];
  session: SessionState;
  isLoading: boolean;
  isAuthenticated: boolean;
  
  // User actions
  setUser: (user: User | null) => void;
  updateUserPreferences: (preferences: Partial<User['preferences']>) => void;
  
  // MFA actions
  setMFAState: (mfa: Partial<MFAState>) => void;
  resetMFAAttempts: () => void;
  recordMFAAttempt: () => void;
  setDeviceList: (devices: MFAState['deviceList']) => void;
  
  // Error management
  addError: (error: Omit<AuthError, 'timestamp'>) => void;
  clearErrors: () => void;
  clearError: (code: string) => void;
  
  // Session management
  updateSession: (sessionUpdate: Partial<SessionState>) => void;
  refreshSession: () => void;
  validateSession: () => boolean;
  
  // Loading state
  setLoading: (isLoading: boolean) => void;
  
  // Authentication
  logout: () => void;
}

const MAX_MFA_ATTEMPTS = 3;
const MFA_COOLDOWN_MINUTES = 15;
const SESSION_TIMEOUT_MINUTES = 30;

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      mfa: {
        isRequired: false,
        attempts: 0,
      },
      errors: [],
      session: {
        lastActive: new Date().toISOString(),
        isValid: false,
      },
      isLoading: false,
      isAuthenticated: false,

      setUser: (user) => {
        set({ 
          user, 
          isAuthenticated: !!user,
          session: user ? {
            lastActive: new Date().toISOString(),
            isValid: true,
            expiresAt: new Date(Date.now() + SESSION_TIMEOUT_MINUTES * 60000).toISOString(),
          } : { lastActive: new Date().toISOString(), isValid: false }
        });
        authLogger.logAudit('USER_STATE_CHANGE', {
          correlationId: crypto.randomUUID(),
          username: user?.email
        }, `User state updated: ${user ? 'logged in' : 'logged out'}`);
      },

      updateUserPreferences: (preferences) => {
        set((state) => ({
          user: state.user ? {
            ...state.user,
            preferences: { ...state.user.preferences, ...preferences }
          } : null
        }));
      },

      setMFAState: (mfaUpdate) => {
        set((state) => ({
          mfa: { ...state.mfa, ...mfaUpdate },
        }));
      },

      resetMFAAttempts: () => {
        set((state) => ({
          mfa: { ...state.mfa, attempts: 0, lastAttemptTime: undefined }
        }));
      },

      recordMFAAttempt: () => {
        set((state) => {
          const attempts = state.mfa.attempts + 1;
          const lastAttemptTime = new Date().toISOString();
          
          if (attempts >= MAX_MFA_ATTEMPTS) {
            get().addError({
              code: 'MFA_MAX_ATTEMPTS',
              message: `Too many failed attempts. Please wait ${MFA_COOLDOWN_MINUTES} minutes.`,
              context: { attempts, cooldownMinutes: MFA_COOLDOWN_MINUTES }
            });
          }
          
          return {
            mfa: { ...state.mfa, attempts, lastAttemptTime }
          };
        });
      },

      setDeviceList: (devices) => {
        set((state) => ({
          mfa: { ...state.mfa, deviceList: devices }
        }));
      },

      addError: (error) => {
        set((state) => ({
          errors: [
            ...state.errors,
            { ...error, timestamp: new Date().toISOString() },
          ].slice(-5), // Keep only last 5 errors
        }));
        authLogger.logError(
          new Error(error.message),
          'STORE_ERROR',
          {
            correlationId: crypto.randomUUID(),
            ...error.context
          }
        );
      },

      clearErrors: () => set({ errors: [] }),

      clearError: (code) => {
        set((state) => ({
          errors: state.errors.filter(error => error.code !== code)
        }));
      },

      updateSession: (sessionUpdate) => {
        set((state) => ({
          session: { ...state.session, ...sessionUpdate }
        }));
      },

      refreshSession: () => {
        const now = new Date();
        set((state) => ({
          session: {
            ...state.session,
            lastActive: now.toISOString(),
            expiresAt: new Date(now.getTime() + SESSION_TIMEOUT_MINUTES * 60000).toISOString()
          }
        }));
      },

      validateSession: () => {
        const state = get();
        if (!state.session.expiresAt) return false;
        
        const isExpired = new Date(state.session.expiresAt) <= new Date();
        if (isExpired) {
          get().logout();
          get().addError({
            code: 'SESSION_EXPIRED',
            message: 'Your session has expired. Please log in again.'
          });
          return false;
        }
        
        return state.session.isValid;
      },

      setLoading: (isLoading) => set({ isLoading }),

      logout: () => {
        tokenManager.clearTokens();
        set({
          user: null,
          isAuthenticated: false,
          mfa: { isRequired: false, attempts: 0 },
          session: { lastActive: new Date().toISOString(), isValid: false },
          errors: [],
        });
        authLogger.logAudit('LOGOUT', {
          correlationId: crypto.randomUUID()
        }, 'User logged out successfully');
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => sessionStorage),
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        session: {
          lastActive: state.session.lastActive,
          deviceId: state.session.deviceId,
        }
      }),
    }
  )
); 