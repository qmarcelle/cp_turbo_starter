import { useAuthStore } from '../auth';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import React from 'react';

const PUBLIC_PATHS = ['/login', '/mfa', '/forgot-password', '/reset-password'];

export function useSessionValidation() {
  const router = useRouter();
  const pathname = usePathname();
  const { validateSession, isAuthenticated, session } = useAuthStore();

  useEffect(() => {
    const isPublicPath = PUBLIC_PATHS.some(path => pathname?.startsWith(path));
    
    if (!isPublicPath) {
      const isValid = validateSession();
      if (!isValid || !isAuthenticated) {
        router.replace('/login');
      }
    }
  }, [pathname, validateSession, isAuthenticated, session.lastActive]);
}

export function withSessionValidation<Props extends object>(
  Component: React.ComponentType<Props>
): React.ComponentType<Props> {
  return function WrappedComponent(props: Props) {
    useSessionValidation();
    return React.createElement(Component, props);
  };
} 