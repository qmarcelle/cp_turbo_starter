interface TokenData {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

class TokenManager {
  private readonly TOKEN_KEY = 'sh_auth_tokens';
  private readonly REFRESH_THRESHOLD = 5 * 60 * 1000; // 5 minutes in milliseconds

  setTokens(tokens: TokenData): void {
    try {
      localStorage.setItem(this.TOKEN_KEY, JSON.stringify(tokens));
    } catch (error) {
      console.error('Failed to store tokens:', error);
      throw new Error('Token storage failed');
    }
  }

  getTokens(): TokenData | null {
    try {
      const tokens = localStorage.getItem(this.TOKEN_KEY);
      return tokens ? JSON.parse(tokens) : null;
    } catch (error) {
      console.error('Failed to retrieve tokens:', error);
      return null;
    }
  }

  clearTokens(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    const tokens = this.getTokens();
    return !!tokens && tokens.expiresAt > Date.now();
  }

  needsRefresh(): boolean {
    const tokens = this.getTokens();
    if (!tokens) return false;
    
    const timeUntilExpiry = tokens.expiresAt - Date.now();
    return timeUntilExpiry < this.REFRESH_THRESHOLD;
  }

  getAuthHeader(): string | null {
    const tokens = this.getTokens();
    return tokens ? `Bearer ${tokens.accessToken}` : null;
  }

  updateAccessToken(newAccessToken: string, newExpiresAt: number): void {
    const currentTokens = this.getTokens();
    if (!currentTokens) return;

    this.setTokens({
      ...currentTokens,
      accessToken: newAccessToken,
      expiresAt: newExpiresAt,
    });
  }
}

export const tokenManager = new TokenManager(); 