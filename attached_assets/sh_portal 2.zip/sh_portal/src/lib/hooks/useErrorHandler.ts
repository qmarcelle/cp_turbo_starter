import { useState, useCallback } from 'react';
import { authLogger } from '@/utils/logging/auth-logger';

const MAX_RETRY_ATTEMPTS = 3;
const INITIAL_RETRY_DELAY = 1000;
const RETRY_MULTIPLIER = 2;
const MAX_RETRY_DELAY = 8000;

interface ErrorState {
  message: string;
  code?: string;
  retryCount: number;
  lastAttempt?: Date;
}

export function useErrorHandler() {
  const [error, setError] = useState<ErrorState | null>(null);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const handleError = useCallback((err: unknown) => {
    authLogger.logError(
      err instanceof Error ? err : new Error(String(err)),
      'ERROR_HANDLER',
      { correlationId: crypto.randomUUID() }
    );

    const isNetworkError = err instanceof Error && (err.message.includes('network') || err.message.includes('connection'));
    const currentRetryCount = error?.retryCount || 0;

    if (isNetworkError && currentRetryCount < MAX_RETRY_ATTEMPTS) {
      const delay = Math.min(
        INITIAL_RETRY_DELAY * Math.pow(RETRY_MULTIPLIER, currentRetryCount),
        MAX_RETRY_DELAY
      );

      setError({
        message: 'Unable to connect. Please check your connection and try again.',
        retryCount: currentRetryCount + 1,
        lastAttempt: new Date(),
      });

      setTimeout(clearError, delay);
      return;
    }

    if (currentRetryCount >= MAX_RETRY_ATTEMPTS) {
      setError({
        message: 'An unexpected error occurred. Please try again later.',
        code: 'SYSTEM_ERROR',
        retryCount: currentRetryCount,
        lastAttempt: new Date(),
      });
    }

    setError({
      message: err instanceof Error ? err.message : 'An unexpected error occurred',
      retryCount: 0,
      lastAttempt: new Date(),
    });
  }, [error, clearError]);

  const canRetry = useCallback(() => {
    if (!error) return false;
    return error.retryCount < MAX_RETRY_ATTEMPTS;
  }, [error]);

  return {
    error: error?.message || null,
    errorCode: error?.code,
    setError: handleError,
    clearError,
    canRetry,
    retryCount: error?.retryCount || 0,
  };
} 