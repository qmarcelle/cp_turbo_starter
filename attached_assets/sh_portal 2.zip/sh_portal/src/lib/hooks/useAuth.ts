'use client';

import { useCallback } from 'react';
import { useAuthStore } from '../store/auth';
import { useRouter } from 'next/navigation';

export function useAuth() {
  const store = useAuthStore();
  const router = useRouter();

  const login = useCallback(async (username: string, password: string) => {
    store.setLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        store.addError({
          code: 'LOGIN_ERROR',
          message: data.message || 'Login failed'
        });
        return false;
      }

      if (data.mfaRequired) {
        store.setMFAState({
          isRequired: true,
          deviceList: data.deviceList
        });
        router.push('/mfa');
        return true;
      }

      store.setUser(data.user);
      router.push('/dashboard');
      return true;
    } catch (error: any) {
      store.addError({
        code: 'LOGIN_ERROR',
        message: error.message || 'Login failed'
      });
      return false;
    } finally {
      store.setLoading(false);
    }
  }, [store, router]);

  const selectMFADevice = useCallback(async (deviceId: string) => {
    store.setLoading(true);
    try {
      const response = await fetch('/api/auth/mfa/select-device', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        store.addError({
          code: 'MFA_DEVICE_ERROR',
          message: data.message || 'Device selection failed'
        });
        return false;
      }

      store.setMFAState({ deviceId });
      return true;
    } catch (error: any) {
      store.addError({
        code: 'MFA_DEVICE_ERROR',
        message: error.message || 'Device selection failed'
      });
      return false;
    } finally {
      store.setLoading(false);
    }
  }, [store]);

  const verifyMFACode = useCallback(async (code: string) => {
    store.setLoading(true);
    try {
      store.recordMFAAttempt();
      
      const response = await fetch('/api/auth/mfa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          code,
          deviceId: store.mfa.deviceId 
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        store.addError({
          code: 'MFA_VERIFICATION_ERROR',
          message: data.message || 'Code verification failed'
        });
        return false;
      }

      store.setUser(data.user);
      store.resetMFAAttempts();
      router.push('/dashboard');
      return true;
    } catch (error: any) {
      store.addError({
        code: 'MFA_VERIFICATION_ERROR',
        message: error.message || 'Code verification failed'
      });
      return false;
    } finally {
      store.setLoading(false);
    }
  }, [store, router]);

  const logout = useCallback(async () => {
    store.setLoading(true);
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      store.logout();
      router.replace('/login');
    } catch (error: any) {
      store.addError({
        code: 'LOGOUT_ERROR',
        message: error.message || 'Logout failed'
      });
    } finally {
      store.setLoading(false);
    }
  }, [store, router]);

  return {
    user: store.user,
    isAuthenticated: store.isAuthenticated,
    isLoading: store.isLoading,
    mfa: store.mfa,
    errors: store.errors,
    session: store.session,
    login,
    logout,
    selectMFADevice,
    verifyMFACode,
    clearError: store.clearError,
    clearErrors: store.clearErrors,
    updateUserPreferences: store.updateUserPreferences,
  };
} 