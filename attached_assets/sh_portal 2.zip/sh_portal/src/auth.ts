// @src/auth.ts
import NextAuth, { DefaultSession } from "next-auth"
import type { JWT } from "next-auth/jwt"
import Credentials from "next-auth/providers/credentials"
import { authConfig } from "./auth.config"
import { esApi } from "./utils/api/esApi"

type LoginStatus = 'SUCCESS' | 'ERROR' | 'MFA_REQUIRED';

interface LoginResponse {
  status: LoginStatus;
  userToken: string;
  accessToken: string;
  interactionId?: string;
  interactionToken?: string;
  requiresMfa: boolean;
  message?: string;
  devices?: Array<{
    id: string;
    type: string;
    value: string;
  }>;
}

interface AuthUser {
  id: string;
  name: string;
  tokens: {
    accessToken: string;
    interactionId?: string;
    interactionToken?: string;
  };
  requiresMfa?: boolean;
}

// Extend the built-in types
declare module "next-auth" {
  interface User {
    id?: string;
    name?: string | null;
    tokens?: {
      accessToken: string;
      interactionId?: string;
      interactionToken?: string;
    };
    requiresMfa?: boolean;
  }

  interface Session extends DefaultSession {
    user: {
      id?: string;
      requiresMfa?: boolean;
      tokens?: AuthUser['tokens'];
    } & DefaultSession["user"]
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    name?: string | null;
    tokens?: {
      accessToken: string;
      interactionId?: string;
      interactionToken?: string;
    };
    requiresMfa?: boolean;
  }
}

export const { 
  handlers: { GET, POST },
  auth,
  signIn,
  signOut
} = NextAuth({
  ...authConfig,
  providers: [
    Credentials({
      credentials: {
        username: { type: "text" },
        password: { type: "password" }
      },
      async authorize(credentials: Record<string, unknown> | undefined) {
        if (!credentials?.username || !credentials?.password) {
          return null;
        }

        try {
          const response = await esApi.post<LoginResponse>('/auth/login', {
            username: credentials.username,
            password: credentials.password
          });

          const user = {
            id: response.userToken,
            name: credentials.username as string,
            tokens: {
              accessToken: response.accessToken,
              interactionId: response.interactionId,
              interactionToken: response.interactionToken
            },
            requiresMfa: response.requiresMfa
          };

          if (response.status === 'SUCCESS') {
            return user;
          }

          if (response.status === 'MFA_REQUIRED') {
            return { ...user, requiresMfa: true };
          }

          return null;
        } catch (error) {
          console.error('Auth error:', error);
          return null;
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.tokens = user.tokens;
        token.requiresMfa = user.requiresMfa;
      }
      return token;
    },
    async session({ session, token }) {
      if (token && token.id) {
        session.user.id = token.id;
        session.user.tokens = token.tokens;
        session.user.requiresMfa = token.requiresMfa;
      }
      return session;
    }
  },
  pages: {
    signIn: '/login',
    error: '/error'
  }
});