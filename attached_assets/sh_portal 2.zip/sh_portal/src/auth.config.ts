// @src/auth.config.ts
import type { NextAuthConfig } from "next-auth"
import { NextResponse } from "next/server"

export const authConfig = {
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: '/login',
    error: '/error'
  },
  callbacks: {
    authorized({ auth, request }) {
      const isLoggedIn = !!auth?.user;
      const isMfaComplete = auth?.user && !auth.user.requiresMfa;
      const isAuthPage = request.nextUrl.pathname.startsWith('/login');
      const isMfaPage = request.nextUrl.pathname.startsWith('/auth/mfa');

      // Allow public access to auth pages
      if (isAuthPage) {
        if (isLoggedIn) return NextResponse.redirect(new URL('/dashboard', request.nextUrl));
        return true;
      }

      // Handle MFA flow
      if (isMfaPage) {
        if (!isLoggedIn) return NextResponse.redirect(new URL('/login', request.nextUrl));
        if (isMfaComplete) return NextResponse.redirect(new URL('/dashboard', request.nextUrl));
        return true;
      }

      // Require authentication for all other pages
      if (!isLoggedIn) {
        return false;
      }
      
      // Redirect to MFA if required
      if (!isMfaComplete) {
        return NextResponse.redirect(new URL('/auth/mfa', request.nextUrl));
      }

      return true;
    }
  },
  providers: [], // configured in auth.ts
} satisfies NextAuthConfig